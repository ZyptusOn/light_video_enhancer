"""FlashVSR runtime subset bundled by Light Video Enhancer."""
